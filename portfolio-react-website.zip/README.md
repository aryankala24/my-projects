# Personal Portfolio Website

This is a React-based personal portfolio website built with React Router and Tailwind CSS.

## Features
- Multi-page navigation with React Router
- Responsive design using Tailwind CSS
- Contact form with basic submission simulation
- Projects showcase
- About and Home pages

## Installation
1. Clone the repository
2. Run `npm install` to install dependencies
3. Run `npm start` to launch the development server

## Deployment
You can deploy this project using GitHub Pages, Netlify, or Vercel.
