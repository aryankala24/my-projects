function Footer() {
  return (
    <footer className="bg-gray-800 text-white text-center p-4 mt-8">
      <p>© 2025 YourName. All rights reserved.</p>
      <div className="space-x-4 mt-2">
        <a href="https://github.com/yourgithub" target="_blank" rel="noopener noreferrer" className="hover:text-gray-300">GitHub</a>
        <a href="https://linkedin.com/in/yourlinkedin" target="_blank" rel="noopener noreferrer" className="hover:text-gray-300">LinkedIn</a>
        <a href="https://twitter.com/yourtwitter" target="_blank" rel="noopener noreferrer" className="hover:text-gray-300">Twitter</a>
      </div>
    </footer>
  );
}

export default Footer;
