function Home() {
  return (
    <section className="text-center">
      <h1 className="text-4xl font-bold mb-4">Hi, I'm YourName</h1>
      <p className="text-lg mb-6">A passionate Frontend Developer & Designer</p>
      <img src="/assets/profile-pic.jpg" alt="Your Name" className="mx-auto rounded-full w-48 h-48 object-cover" />
    </section>
  );
}

export default Home;
