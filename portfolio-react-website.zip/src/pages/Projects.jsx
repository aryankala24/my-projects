function Projects() {
  const projects = [
    {
      title: "E-commerce Website",
      description: "A responsive React app with shopping cart and API integration.",
      github: "https://github.com/yourgithub/ecommerce",
      live: "https://yourliveurl.com",
    },
    {
      title: "Weather App",
      description: "Fetches weather data using OpenWeatherMap API with dynamic UI.",
      github: "https://github.com/yourgithub/weather-app",
      live: "https://yourliveurl.com/weather",
    },
    {
      title: "Personal Blog",
      description: "A blog platform built with React and Markdown support.",
      github: "https://github.com/yourgithub/blog",
      live: "https://yourliveurl.com/blog",
    },
  ];

  return (
    <section>
      <h2 className="text-3xl font-bold mb-6">Projects</h2>
      <div className="grid gap-6 md:grid-cols-2">
        {projects.map(({ title, description, github, live }, i) => (
          <div key={i} className="border rounded p-4 hover:shadow-lg transition-shadow">
            <h3 className="text-xl font-semibold mb-2">{title}</h3>
            <p className="mb-2">{description}</p>
            <div className="space-x-4">
              <a href={github} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">GitHub</a>
              <a href={live} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:underline">Live Demo</a>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Projects;
