function About() {
  return (
    <section>
      <h2 className="text-3xl font-bold mb-4">About Me</h2>
      <p className="mb-4">
        I am a motivated developer with experience in building web applications using React, JavaScript, and modern CSS frameworks.
      </p>
      <h3 className="text-2xl font-semibold mb-2">Skills</h3>
      <ul className="list-disc list-inside">
        <li>React & React Router</li>
        <li>JavaScript (ES6+)</li>
        <li>Tailwind CSS</li>
        <li>Git & GitHub</li>
        <li>Responsive Design</li>
      </ul>
    </section>
  );
}

export default About;
